<?php
/**
 * The sidebar for our theme.
 *
 * Displays all of the widget area up to the footer.
 *
 * @package Simple Blog Theme
 */
?><!-- Blog Sidebar Widgets Column -->



<div class="col-md-4">
<?php dynamic_sidebar( 'jpen-sidebar-widgets' ); ?>
</div>