# Planned Additions to the Simple Blog Theme 

Listed in order or priority:

- ~~Add formatting to excerpt on posts page.~~ Done, 9.14.16
- ~~Add single.php and content-single.php.~~ Done, 9.14.16
- ~~Add comments to single blog posts.~~ Done, 9.14.16
- ~~Add page.php and content-page.php.~~ Done, 9.17.16
- ~~Add archive.php.~~ Done, 9.17.16
- ~~Add search.php and content-search.php.~~ Done, 9.17.16
- Add 404.php.
- Clean up index.php (remove unused content)
- Display categories and tags on posts